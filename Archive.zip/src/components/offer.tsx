import React from 'react'

const Offer = () => {
  return (
    <div>
      offers
    </div>
  )
}

export default Offer
