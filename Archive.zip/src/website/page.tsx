// src/app/website/page.tsx

const WebsitePage = () => {
  return (
      <div>
        
      </div>
  );
};

export default WebsitePage;